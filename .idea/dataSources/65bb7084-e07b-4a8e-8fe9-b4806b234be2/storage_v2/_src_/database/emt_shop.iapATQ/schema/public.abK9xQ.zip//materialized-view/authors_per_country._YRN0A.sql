create materialized view authors_per_country as
SELECT c.id        AS country_id,
       count(a.id) AS num_authors
FROM country c
         LEFT JOIN author a ON a.country_id = c.id
GROUP BY c.id;

alter materialized view authors_per_country owner to emt;

