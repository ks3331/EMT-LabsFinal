create materialized view books_per_author as
SELECT a.id        AS author_id,
       count(b.id) AS num_books
FROM author a
         LEFT JOIN book b ON b.author_id = a.id
GROUP BY a.id;

alter materialized view books_per_author owner to emt;

